function loginctnr() {
  document.getElementById("pul").style.display = "block";
}

function loginctnrcancel() {
	document.getElementById("pul").style.display = "none";
}

function regctnr(){
	document.getElementById("pur").style.display = "block";
}

function regctnrcancel(){
	document.getElementById("pur").style.display = "none";
}